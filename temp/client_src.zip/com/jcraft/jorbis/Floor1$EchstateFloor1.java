package com.jcraft.jorbis;

class Floor1$EchstateFloor1 {
	int[] codewords;
	float[] curve;
	long frameno;
	long codes;
	final Floor1 this$0;

	Floor1$EchstateFloor1(Floor1 floor11) {
		this.this$0 = floor11;
	}
}
