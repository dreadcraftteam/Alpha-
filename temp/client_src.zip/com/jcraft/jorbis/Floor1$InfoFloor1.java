package com.jcraft.jorbis;

class Floor1$InfoFloor1 {
	static final int VIF_POSIT = 63;
	static final int VIF_CLASS = 16;
	static final int VIF_PARTS = 31;
	int partitions;
	int[] partitionclass;
	int[] class_dim;
	int[] class_subs;
	int[] class_book;
	int[][] class_subbook;
	int mult;
	int[] postlist;
	float maxover;
	float maxunder;
	float maxerr;
	int twofitminsize;
	int twofitminused;
	int twofitweight;
	float twofitatten;
	int unusedminsize;
	int unusedmin_n;
	int n;
	final Floor1 this$0;

	Floor1$InfoFloor1(Floor1 floor11) {
		this.this$0 = floor11;
		this.partitionclass = new int[31];
		this.class_dim = new int[16];
		this.class_subs = new int[16];
		this.class_book = new int[16];
		this.class_subbook = new int[16][];
		this.postlist = new int[65];

		for(int i2 = 0; i2 < this.class_subbook.length; ++i2) {
			this.class_subbook[i2] = new int[8];
		}

	}

	void free() {
		this.partitionclass = null;
		this.class_dim = null;
		this.class_subs = null;
		this.class_book = null;
		this.class_subbook = (int[][])null;
		this.postlist = null;
	}

	Object copy_info() {
		Floor1$InfoFloor1 floor1$InfoFloor11 = this;
		Floor1$InfoFloor1 floor1$InfoFloor12 = new Floor1$InfoFloor1(this.this$0);
		floor1$InfoFloor12.partitions = this.partitions;
		System.arraycopy(this.partitionclass, 0, floor1$InfoFloor12.partitionclass, 0, 31);
		System.arraycopy(this.class_dim, 0, floor1$InfoFloor12.class_dim, 0, 16);
		System.arraycopy(this.class_subs, 0, floor1$InfoFloor12.class_subs, 0, 16);
		System.arraycopy(this.class_book, 0, floor1$InfoFloor12.class_book, 0, 16);

		for(int i3 = 0; i3 < 16; ++i3) {
			System.arraycopy(floor1$InfoFloor11.class_subbook[i3], 0, floor1$InfoFloor12.class_subbook[i3], 0, 8);
		}

		floor1$InfoFloor12.mult = floor1$InfoFloor11.mult;
		System.arraycopy(floor1$InfoFloor11.postlist, 0, floor1$InfoFloor12.postlist, 0, 65);
		floor1$InfoFloor12.maxover = floor1$InfoFloor11.maxover;
		floor1$InfoFloor12.maxunder = floor1$InfoFloor11.maxunder;
		floor1$InfoFloor12.maxerr = floor1$InfoFloor11.maxerr;
		floor1$InfoFloor12.twofitminsize = floor1$InfoFloor11.twofitminsize;
		floor1$InfoFloor12.twofitminused = floor1$InfoFloor11.twofitminused;
		floor1$InfoFloor12.twofitweight = floor1$InfoFloor11.twofitweight;
		floor1$InfoFloor12.twofitatten = floor1$InfoFloor11.twofitatten;
		floor1$InfoFloor12.unusedminsize = floor1$InfoFloor11.unusedminsize;
		floor1$InfoFloor12.unusedmin_n = floor1$InfoFloor11.unusedmin_n;
		floor1$InfoFloor12.n = floor1$InfoFloor11.n;
		return floor1$InfoFloor12;
	}
}
