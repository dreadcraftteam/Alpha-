package net.minecraft.src;

public class MinecraftException extends RuntimeException {
	public MinecraftException(String message) {
		super(message);
	}
}
