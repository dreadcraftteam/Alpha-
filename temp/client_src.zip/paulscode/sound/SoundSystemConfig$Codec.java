package paulscode.sound;

import java.util.Locale;

class SoundSystemConfig$Codec {
	public String extensionRegX = "";
	public Class iCodecClass;

	public SoundSystemConfig$Codec(String string1, Class class2) {
		if(string1 != null && string1.length() > 0) {
			this.extensionRegX = ".*";

			for(int i4 = 0; i4 < string1.length(); ++i4) {
				String string3 = string1.substring(i4, i4 + 1);
				this.extensionRegX = this.extensionRegX + "[" + string3.toLowerCase(Locale.ENGLISH) + string3.toUpperCase(Locale.ENGLISH) + "]";
			}

			this.extensionRegX = this.extensionRegX + "$";
		}

		this.iCodecClass = class2;
	}

	public ICodec getInstance() {
		if(this.iCodecClass == null) {
			return null;
		} else {
			Object object1 = null;

			try {
				object1 = this.iCodecClass.newInstance();
			} catch (InstantiationException instantiationException3) {
				this.instantiationErrorMessage();
				return null;
			} catch (IllegalAccessException illegalAccessException4) {
				this.instantiationErrorMessage();
				return null;
			} catch (ExceptionInInitializerError exceptionInInitializerError5) {
				this.instantiationErrorMessage();
				return null;
			} catch (SecurityException securityException6) {
				this.instantiationErrorMessage();
				return null;
			}

			if(object1 == null) {
				this.instantiationErrorMessage();
				return null;
			} else {
				return (ICodec)object1;
			}
		}
	}

	private void instantiationErrorMessage() {
		SoundSystemConfig.access$000("Unrecognized ICodec implementation in method \'getInstance\'.  Ensure that the implementing class has one public, parameterless constructor.");
	}
}
